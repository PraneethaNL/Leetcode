Tech_Interviews
===============

technical interview problems written in python 2.7
